# 🎬 Movie Explorer

A React app to search and browse movies using the [TMDB API](https://www.themoviedb.org/documentation/api).

## Features
- Search movies (debounced)
- Movie details page (overview, cast, director, runtime, genres)
- Ratings (stars + score + votes)
- Category (genre) filters
- Pagination
- Responsive design
- Loading indicators and error handling (with retry)
- Routing with React Router

## Tech
React 18, Vite, React Router v6, custom hooks (`useFetch`, `useDebounce`)

## Setup
1. Get a free API key from https://www.themoviedb.org/settings/api
2. `cp .env.example .env` and paste your key into `VITE_TMDB_API_KEY`
3. `npm install`
4. `npm run dev`

## Build
`npm run build` → output in `dist/`

## Deploy
- **Vercel / Netlify:** import the GitHub repo, add `VITE_TMDB_API_KEY` as an environment variable, deploy.
  (`vercel.json` and `public/_redirects` already handle SPA routing.)

## Project structure
```
src/
  api/          tmdb.js (URL builder + fetch helper)
  hooks/        useFetch.js, useDebounce.js
  components/   SearchBar, CategoryFilter, MovieCard, MovieGrid, Rating, Pagination, Loader, ErrorMessage
  pages/        Home, MovieDetails, NotFound
```

## AI-Assisted Activity
- Components were generated with AI, then refactored into small reusable pieces (e.g. `MovieCard`, `Rating`, `Loader`).
- Data fetching logic was extracted into the reusable `useFetch` hook.
- AI helped troubleshoot state issues: stale results from race conditions (fixed with `AbortController`),
  page not resetting on new search (fixed with a `useEffect`), and too many API calls (fixed with `useDebounce`).
