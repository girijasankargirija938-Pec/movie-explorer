import { useState, useEffect } from "react";
import { fetchJson } from "../api/tmdb.js";

// Reusable data fetching hook: returns { data, loading, error }
// Pass null as url to skip fetching.
export default function useFetch(url) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(Boolean(url));
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!url) return;
    const controller = new AbortController();
    setLoading(true);
    setError(null);

    fetchJson(url, controller.signal)
      .then(setData)
      .catch((err) => {
        if (err.name === "AbortError") return; // ignore cancelled requests
        setError(err.message || "Something went wrong");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort(); // avoids race conditions
  }, [url]);

  return { data, loading, error };
}
