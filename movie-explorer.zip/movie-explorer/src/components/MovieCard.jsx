import { Link } from "react-router-dom";
import Rating from "./Rating.jsx";
import { IMG_BASE } from "../api/tmdb.js";

export default function MovieCard({ movie }) {
  const year = movie.release_date ? movie.release_date.slice(0, 4) : "—";
  const poster = movie.poster_path
    ? `${IMG_BASE}/w342${movie.poster_path}`
    : "https://placehold.co/342x513?text=No+Poster";

  return (
    <Link to={`/movie/${movie.id}`} className="card">
      <img src={poster} alt={movie.title} loading="lazy" />
      <div className="card-body">
        <h3>{movie.title}</h3>
        <p className="muted">{year}</p>
        <Rating value={movie.vote_average} />
      </div>
    </Link>
  );
}
