export default function Loader({ text = "Loading..." }) {
  return (
    <div className="loader" role="status" aria-live="polite">
      <div className="spinner" />
      <p>{text}</p>
    </div>
  );
}
