// Shows TMDB rating (0-10) as 5 stars plus the numeric score
export default function Rating({ value = 0, votes }) {
  const score = Number(value) || 0;
  const stars = Math.round(score / 2);
  return (
    <div className="rating" title={`${score.toFixed(1)} / 10`}>
      <span className="stars" aria-hidden="true">
        {"★".repeat(stars)}{"☆".repeat(5 - stars)}
      </span>
      <span className="score">{score ? score.toFixed(1) : "N/A"}</span>
      {votes ? <span className="votes">({votes.toLocaleString()})</span> : null}
    </div>
  );
}
