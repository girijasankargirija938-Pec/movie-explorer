export default function SearchBar({ value, onChange }) {
  return (
    <input
      type="search"
      className="search"
      placeholder="Search movies..."
      value={value}
      onChange={(e) => onChange(e.target.value)}
      aria-label="Search movies"
    />
  );
}
