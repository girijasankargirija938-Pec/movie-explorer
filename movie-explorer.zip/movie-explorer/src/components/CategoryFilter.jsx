export default function CategoryFilter({ genres, selected, onSelect }) {
  return (
    <div className="filters" role="group" aria-label="Filter by category">
      <button
        className={selected === "" ? "chip active" : "chip"}
        onClick={() => onSelect("")}
      >
        All
      </button>
      {genres.map((g) => (
        <button
          key={g.id}
          className={String(selected) === String(g.id) ? "chip active" : "chip"}
          onClick={() => onSelect(String(g.id))}
        >
          {g.name}
        </button>
      ))}
    </div>
  );
}
