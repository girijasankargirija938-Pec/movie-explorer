import { useState, useEffect, useMemo } from "react";
import useFetch from "../hooks/useFetch.js";
import useDebounce from "../hooks/useDebounce.js";
import { buildUrl } from "../api/tmdb.js";
import SearchBar from "../components/SearchBar.jsx";
import CategoryFilter from "../components/CategoryFilter.jsx";
import MovieGrid from "../components/MovieGrid.jsx";
import Pagination from "../components/Pagination.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";

const GENRES_URL = buildUrl("/genre/movie/list");

export default function Home() {
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("");
  const [page, setPage] = useState(1);
  const [retryKey, setRetryKey] = useState(0);

  const debouncedQuery = useDebounce(query.trim(), 500);

  // Reset to page 1 whenever the search or category changes
  useEffect(() => {
    setPage(1);
  }, [debouncedQuery, genre]);

  // Decide which endpoint to call: search > category > popular
  const moviesUrl = useMemo(() => {
    let url;
    if (debouncedQuery) {
      url = buildUrl("/search/movie", { query: debouncedQuery, page });
    } else if (genre) {
      url = buildUrl("/discover/movie", { with_genres: genre, page, sort_by: "popularity.desc" });
    } else {
      url = buildUrl("/movie/popular", { page });
    }
    // retryKey makes the url unique so "Try again" refetches
    return retryKey ? `${url}&_r=${retryKey}` : url;
  }, [debouncedQuery, genre, page, retryKey]);

  const { data, loading, error } = useFetch(moviesUrl);
  const { data: genreData } = useFetch(GENRES_URL);

  const heading = debouncedQuery
    ? `Results for "${debouncedQuery}"`
    : genre
    ? "Movies by category"
    : "Popular movies";

  return (
    <>
      <SearchBar value={query} onChange={setQuery} />
      <CategoryFilter genres={genreData?.genres || []} selected={genre} onSelect={setGenre} />
      {debouncedQuery && genre && (
        <p className="muted center">Category filter is paused while searching.</p>
      )}
      <h2>{heading}</h2>

      {loading && <Loader text="Fetching movies..." />}
      {error && <ErrorMessage message={error} onRetry={() => setRetryKey((k) => k + 1)} />}
      {!loading && !error && data && (
        <>
          <MovieGrid movies={data.results} />
          <Pagination page={page} totalPages={data.total_pages} onChange={setPage} />
        </>
      )}
    </>
  );
}
