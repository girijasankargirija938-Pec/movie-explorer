import { useParams, useNavigate } from "react-router-dom";
import useFetch from "../hooks/useFetch.js";
import { buildUrl, IMG_BASE } from "../api/tmdb.js";
import Rating from "../components/Rating.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";

export default function MovieDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: movie, loading, error } = useFetch(
    buildUrl(`/movie/${id}`, { append_to_response: "credits" })
  );

  if (loading) return <Loader text="Loading movie details..." />;
  if (error)
    return (
      <>
        <button className="back" onClick={() => navigate(-1)}>← Back</button>
        <ErrorMessage message={error} />
      </>
    );
  if (!movie) return null;

  const poster = movie.poster_path
    ? `${IMG_BASE}/w500${movie.poster_path}`
    : "https://placehold.co/500x750?text=No+Poster";
  const cast = movie.credits?.cast?.slice(0, 8).map((c) => c.name).join(", ");
  const director = movie.credits?.crew?.find((c) => c.job === "Director")?.name;

  return (
    <>
      <button className="back" onClick={() => navigate(-1)}>← Back</button>
      <div className="details">
        <img src={poster} alt={movie.title} />
        <div>
          <h1>{movie.title}</h1>
          {movie.tagline && <p className="muted"><em>{movie.tagline}</em></p>}
          <Rating value={movie.vote_average} votes={movie.vote_count} />
          <p className="meta">
            {movie.release_date || "—"} • {movie.runtime ? `${movie.runtime} min` : "—"}
          </p>
          <div className="tags">
            {movie.genres?.map((g) => (
              <span key={g.id} className="chip small">{g.name}</span>
            ))}
          </div>
          <h3>Overview</h3>
          <p>{movie.overview || "No overview available."}</p>
          {director && <p><strong>Director:</strong> {director}</p>}
          {cast && <p><strong>Cast:</strong> {cast}</p>}
        </div>
      </div>
    </>
  );
}
