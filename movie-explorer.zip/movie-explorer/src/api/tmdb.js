const BASE_URL = "https://api.themoviedb.org/3";
const API_KEY = import.meta.env.VITE_TMDB_API_KEY;

export const IMG_BASE = "https://image.tmdb.org/t/p";

// Builds a full TMDB url with the api key and extra query params
export function buildUrl(path, params = {}) {
  const query = new URLSearchParams({ api_key: API_KEY, ...params });
  return `${BASE_URL}${path}?${query.toString()}`;
}

// Generic fetch helper that throws readable errors
export async function fetchJson(url, signal) {
  if (!API_KEY) {
    throw new Error("Missing API key. Add VITE_TMDB_API_KEY to your .env file.");
  }
  const res = await fetch(url, { signal });
  if (res.status === 401) throw new Error("Invalid API key.");
  if (res.status === 404) throw new Error("Not found.");
  if (!res.ok) throw new Error(`Request failed (${res.status}). Please try again.`);
  return res.json();
}
